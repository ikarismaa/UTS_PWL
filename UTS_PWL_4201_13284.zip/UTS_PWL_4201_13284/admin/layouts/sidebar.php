<?php
    include('../config/app.php');

    $sidebar = $_SESSION['sidebar'];
?>
<div class="sidebar">
    <div class="logo-details">
        <i class='bx bxs-shopping-bag-alt'></i>
        <span class="logo_name">sneakresID.</span>
    </div>
    <ul class="nav-links">
        <!-- <li>
            <a href="<?= $app['base_url'] ?>/admin/dashboard" class="<?php if($sidebar == 'dashboard') echo 'active'; ?>">
                <i class='bx bx-grid-alt'></i>
                <span class="links_name">Dashboard</span>
            </a>
        </li> -->
        <li>
            <a href="<?= $app['base_url'] ?>/admin/produk" class="<?php if($sidebar == 'paket') echo 'active'; ?>">
                <i class='bx bx-box'></i>
                <span class="links_name">Produk</span>
            </a>
        </li>

        <li class="log_out">
            <a href="<?= $app['base_url'] ?>/admin/login/logout.php">
                <i class='bx bx-log-out'></i>
                <span class="links_name">Log out</span>
            </a>
        </li>
    </ul>
</div>